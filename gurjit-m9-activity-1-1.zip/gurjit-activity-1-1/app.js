const express = require('express');
const connectDB = require('./database/connect');
const dotenv = require('dotenv');
const path = require('path');
const WebTechnology = require('./database/models/WebTechnology');

// Load .env config and connect to DB
dotenv.config();
connectDB();

const app = express();
const PORT = process.env.PORT || 3000;

// use style.css
app.use(express.static('public'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// 📘 CREATE FORM
app.get('/create', (req, res) => {
  res.render('create');
});

// 📘 CREATE POST
app.post('/api/create', async (req, res) => {
  const { bookname, authorname, releasedyear } = req.body;

  try {
    let record = await WebTechnology.findOne();
    if (!record) record = new WebTechnology({ books: [] });

    record.books.push({ bookname, authorname, releasedyear });
    await record.save();

    res.send('✅ Book added successfully! <a href="/create">Add another</a>');
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error adding book.');
  }
});

// 📗 VIEW ALL BOOKS
app.get('/data', async (req, res) => {
  try {
    const record = await WebTechnology.findOne();
    const books = record ? record.books : [];
    res.render('data', { books });
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error fetching books.');
  }
});

// 📗 VIEW BOOK DETAILS
app.get('/data/:index', async (req, res) => {
  const index = req.params.index;

  try {
    const record = await WebTechnology.findOne();
    const book = record && record.books[index];

    res.render('detail', { book });
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error loading book.');
  }
});

// ✏️ UPDATE FORM
app.get('/update/:index', async (req, res) => {
  const index = req.params.index;

  try {
    const record = await WebTechnology.findOne();
    const book = record && record.books[index];

    if (book) {
      res.render('update', { book, index });
    } else {
      res.status(404).send('❌ Book not found.');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error loading update form.');
  }
});

// ✏️ UPDATE POST
app.post('/api/update/:index', async (req, res) => {
  const index = req.params.index;
  const { bookname, authorname, releasedyear } = req.body;

  try {
    const record = await WebTechnology.findOne();

    if (record && record.books[index]) {
      record.books[index].bookname = bookname;
      record.books[index].authorname = authorname;
      record.books[index].releasedyear = releasedyear;

      await record.save();
      res.send('✅ Book updated successfully! <a href="/data">View All Books</a>');
    } else {
      res.status(404).send('❌ Book not found.');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error updating book.');
  }
});

// 🗑 DELETE
app.get('/api/delete/:index', async (req, res) => {
  const index = req.params.index;

  try {
    const record = await WebTechnology.findOne();

    if (record && record.books[index]) {
      record.books.splice(index, 1);
      await record.save();
      res.send('🗑 Book deleted successfully! <a href="/data">Back to list</a>');
    } else {
      res.status(404).send('❌ Book not found.');
    }
  } catch (err) {
    console.error(err);
    res.status(500).send('❌ Error deleting book.');
  }
});

// Start server
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
