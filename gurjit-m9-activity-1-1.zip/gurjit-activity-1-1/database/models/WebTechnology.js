const mongoose = require('mongoose');

const BookSchema = new mongoose.Schema({
  bookname: {
    type: String,
    required: true
  },
  authorname: {
    type: String,
    required: true
  },
  releasedyear: {
    type: Number,
    required: true
  }
});

const WebTechnologySchema = new mongoose.Schema({
  books: [BookSchema]
});

// Explicitly use 'WebTechnology' as the collection name
const WebTechnology = mongoose.model('WebTechnology', WebTechnologySchema, 'WebTechnology');

module.exports = WebTechnology;
